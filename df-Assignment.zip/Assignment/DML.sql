select Class_Code, count(Stu_IC)
from ENROLL
group by Class_Code
having count(Stu_IC) < 2;

create trigger 

alter ENROLL drop Sub_Code;

CREATE VIEW SubjectFave AS
SELECT Stu_IC, Sub_Code
FROM ENROLL;

select * from SubjectFave;

select Sub_Code, count(Stu_IC)
from SubjectFave
order by Sub_Code
limit 3;