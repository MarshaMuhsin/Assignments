Create table SUBJECT
(Sub_Code int not null primary key,
Sub_Name varchar(30),
Sub_Credit int
);
Create table BRANCH
(Branch_ID int not null primary key,
Branch_Location varchar(30),
Branch_Head varchar(30)
);
Create table TEACHER
(Teach_ID int not null primary key,
Teach_Name varchar(30),
Teach_Address varchar(50),
Teach_Phone char(11),
Teach_Email varchar(30),
Teach_Age int,
Teach_Qualify varchar(50),
Branch_ID int,
Foreign key (Branch_ID) references BRANCH
);
Create table STUDENT
(Stu_IC char(14) not null primary key,
Stu_Name varchar(30),
Stu_Address varchar(50),
Stu_Phone char(11),
Stu_Age int
);
Create table CLASSES
(Class_Code int not null primary key,
Class_Name varchar(30),
Class_Location varchar(15),
Sub_Code int,
Teach_ID int,
Branch_ID int,
Foreign key (Sub_Code) references SUBJECT,
Foreign key (Teach_ID) references TEACHER,
Foreign key (Branch_ID) references BRANCH
);
Create table ENROLL
(Stu_IC int not null primary key,
Class_Code int not null,
Sub_Code int,
Enroll_Grade char(2),
Enroll_Date date,
Foreign key(Stu_IC) references STUDENT,
Foreign key(Class_Code) references CLASSES,
Foreign key (Sub_Code) references SUBJECT
);

Insert into SUBJECT values
(1119, 'Bahasa Inggeris', 4),
(3472, 'Additional Mathematics', 3),
(1103, 'Bahasa Melayu', 4),
(4551, 'Biology', 3),
(4531, 'Physics', 3);
Insert into BRANCH values
(01, 'CYBERJAYA', 'CYBERJAYA'),
(02, 'PUCHONG', 'CYBERJAYA'),
(03, 'PUTRAJAYA', 'CYBERJAYA');
Insert into TEACHER values
(1001, 'Sarah', 'CYBERJAYA' , '60117625349', 'sarahiman@gmail.com', 25, 'Bachelor in English Language and Literature', 01),
(1002, 'Tisya', 'PUCHONG', '60129876543', 'batrisyia@hotmail.com', 20, 'Bachelor in Mathematics' , 02),
(1003, 'Marsha', 'PUTRAJAYA', '60129976543', 'marshamuhsin@yahoo.com', 26, 'Bachelor in Science', 03),
(1004, 'Adlin', 'CYBERJAYA', '60134526982', 'adlin82@gmail.com', 25, 'Bachelor in Advance Mathematics', 01);
Insert into STUDENT values
('021224-08-6677', 'Isyraf Danish', 'PUTRAJAYA', '60128867921', 17),
('030222-05-6989', 'Thinesh', 'CYBERJAYA', '60137162874', 16),
('030518-14-8956', 'Crystal Dania', 'CYBERJAYA', '60176289303', 16),
('040830-14-2351', 'Yusuf Iskandar', 'CYBERJAYA', '60197772332', 15),
('021106-09-5412', 'Sarah Ilham Shah', 'CYBERJAYA', '60121541517', 17),
('020101-01-0321', 'Anthony Jack', 'PUCHONG', '60172238989', 17); 
Insert into CLASSES values
(01, 'Infinity', 'Wing A', 4551, 1003, 03),
(02, 'Space', 'Wing A', 4531, 1003, 03),
(03, 'Reality', 'Wing B', 1103, 1001, 01),
(04, 'Mind', 'Wing B', 3472, 1004, 01),
(05, 'Time', 'Wing C', 1119, 1001, 01),
(06, 'Power', 'Wing C', 3472, 1002, 02);
Insert into ENROLL values
('021224-08-6677', 01, 4551,'A', '19-01-02'),
('030518-14-8956', 05, 4531,'B', '19-01-02'),
('040830-14-2351', 04, 1103,'C', '19-01-12'),
('021106-09-5412', 04, 3472,'B', '19-01-08'),
('030222-05-6989', 03, 1119,'A', '19-02-02'),
('020101-01-0321', 06, 3472,'B', '19-02-02');

Insert into STUDENT values
('020831-10-5176', 'Alia', 'Putrajaya', '60129254715', 17),
('021110-10-5331', 'Muhd Muhsin', 'Putrajaya', '60104567891', 17),
('020430-10-5204', 'Angelina', 'Putrajaya', '60116350304',17),
('020717-11-5356', 'Farah', 'Putrajaya', '60122129077', 17);
Insert into ENROLL values
('020831-10-5176', 01, 4551,'C', '19-01-02'),
('021110-10-5331', 01, 4551,'B', '19-01-02'),
('020430-10-5204', 01, 4551,'A', '19-01-02'),
('020717-11-5356', 01, 4551,'B', '19-01-02');