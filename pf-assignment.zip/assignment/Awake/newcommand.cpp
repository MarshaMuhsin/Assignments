#include <iostream>
#include <vector>
#include <sstream> // stringstream
using namespace std;

struct Item
{
	int cost;
	string name;
	int month;
	int year;
	
	Item(int c, int m, int y)
	{
		cost = c;
		month = m;
		year = y;
	}
	
	int GetNumericData(string name)
	{
		if (name == "cost")
			return cost;
		else if (name == "month")
			return month;
		else if (name == "year")
			return year;
	}

	bool CompareNumeric(string name, char op, int num)
	{
		
		int a = GetNumericData(name);
		
		// Assume a is valid
		switch(op)
		{
			case '=':
			{
				if (a == num)
					return true;
				else
					return false;
			}
			break;
			
			case '<':
			{
				if (a < num)
					return true;
				else
					return false;
			}
			break;
			
			case '>':
			{
				if (a > num)
					return true;
				else
					return false;
			}
			break;
		}
	}

	void Show()
	{
		cout << "Cost = " << cost << ", "
			 << "Year = " << year << ", "
			 << "Month = " << month << endl;
	}
};

void CreateDatabase(vector<Item>& database)
{
	// Create some items for testing
	Item a1(1000,  9, 2015);
	Item a2( 750, 12, 2000);
	Item a3( 250,  1, 2008);
	database.push_back(a1);
	database.push_back(a2);
	database.push_back(a3);
}

void ProcessCommand(string command,
					string& variable,
					char& op,
					int& num)
{
	stringstream ss;
	ss << command;
	
	ss >> variable;
	ss >> op;
	ss >> num;
}
						

int main()
{
	vector<Item> database;
	CreateDatabase(database);
	
	string command;
	cout << "Enter command: ";
	getline(cin, command);
	
	string name;
	char op;
	int num;
	
	ProcessCommand(command, name, op, num);
	
	cout << name << "\n" << op << "\n" << num << endl;
	
	for (int i = 0; i < database.size(); ++i)
	{
		if (database[i].CompareNumeric(name, op, num))
			database[i].Show();
	}
}








