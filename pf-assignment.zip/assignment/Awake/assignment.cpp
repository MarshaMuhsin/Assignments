#include <iostream>
#include <string> // substr()
#include <cctype> // isupper(), tolower()
using namespace std;

string Lowercase(string text)
{
	for (int i = 0; i < text.size(); ++i)
		if (isupper(text[i]))
			text[i] = tolower(text[i]);
	return text;
}

int Find(string A, string B)
{
	Lowercase(A);
	Lowercase(B);
	
	for (int i = 0; i <= A.size() - B.size(); ++i)
	{
		if (A.substr(i, B.size()) == B)
			return i;
	}
	
	return -1;
}

int main()
{
	string A, B;
	cout << "Enter A: ";
	// cin >> A;
	getline(cin, A);
	cout << "Enter B: ";
	// cin >> B;
	getline(cin, B);
	
	int index = Find(A, B);
	if (index >= 0)
		cout << "Found B at index: "
			 << index << endl;
	else
		cout << "B not found." << endl;
}





