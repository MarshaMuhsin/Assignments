#include <iostream>
#include <vector>
#include <algorithm> // sort
using namespace std;

struct Item
{
	string name;
	int cost;
	
	Item(string n, int c)
	{
		name = n;
		cost = c;
	}
	
	void show()
	{
		cout << "Name: " << name << ", Cost = " << cost << endl;
	}
};

void show(vector<Item>& a, int size)
{
	for (int i = 0; i < a.size(); ++i)
		a[i].show();
	cout << endl;
}

struct Compare
{
	string field;
	char op;
	
	bool operator() (Item a, Item b)
	{
		// cout << field << endl;
		if (field == "name")
		{
			if (op == '<')
				return a.name < b.name;
			else if (op == '>')
				return a.name > b.name;
		}
		else if (field == "cost")
		{
			if (op == '<')
				return a.cost < b.cost;
			else if (op == '>')
			{
				// cout << field << endl;
				// cout << op << endl;
				return a.cost > b.cost;
			}
		}
	}
};

int main()
{
	// int a[] = {1, 3, 2, 9, 4, 8, 7, 0};
	vector<Item> a;
	a.push_back(Item("justin",  500));
	a.push_back(Item("bieber", 1000));
	a.push_back(Item("selena", 2500));
	a.push_back(Item("gomez", 2000));
	// int size = sizeof(a) / sizeof(int);
	
	string name;
	cout << "Enter the field to sort: ";
	cin >> name;
	
	cout << "Before sorting: " << endl;
	show(a, a.size());
	
	string input;
	cout << "Enter 'ascending' or 'descending': ";
	cin >> input;
	
	if (input == "descending")
	{
		Compare largerThan;
		largerThan.field = name;
		largerThan.op = '>';
		
		sort(a.begin(), a.end(), largerThan);
	}
	else if (input == "ascending")
	{
		Compare smallerThan;
		smallerThan.field = name;
		smallerThan.op = '<';
		
		sort(a.begin(), a.end(), smallerThan);
	}
	else
		cout << "Not sure what to do" << endl;
	
	cout << "Before sorting: " << endl;
	show(a, a.size());
}


