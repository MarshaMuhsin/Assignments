#include "test.h"
#include <iostream>
#include <iomanip>
#include <cctype>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <vector>
using namespace std;

ifstream inFile;
ofstream outFile;

//insertRecord is a function for the user to insert an inventory record
void StoreItem::insertRecord()
{
	//The title
	cout << "--------------------------------------------------------------------------------------------------------" << endl
		 << "|                                          RECORD INSERTION                                            |" << endl
		 << "--------------------------------------------------------------------------------------------------------" << endl << endl;
	
	int numOfRecords;
	
	cout << "How many records do you want to insert? ";
	cin >> numOfRecords;
	
	record temporary;
	for (int i = 0; i < numOfRecords; i++)
	{
		cout << endl << endl << "Item ID: ";
		cin >> temporary.itemID;
		cin.ignore();
		cout << endl << "Item Name: ";
		getline(cin, temporary.itemName);
		cout << endl << "Item Description: ";
		getline(cin, temporary.itemDescription);
		cout << endl << "Category: ";
		getline(cin, temporary.category);
		cout << endl << "Manufacturer: ";
		getline(cin, temporary.manufacturer);
		cout << endl << "Selling Price: ";
		cin >> temporary.sellingPrice;
		while (temporary.sellingPrice < 0)
		{
			cin.ignore();
			cin.clear();
			cout << "Invalid input!";
			cout << endl << "Selling Price: ";
			cin >> temporary.sellingPrice;
		}
		cout << endl << "Cost Price: ";
		cin >> temporary.costPrice;
		while (temporary.costPrice < 0)
		{
			cin.ignore();
			cin.clear();
			cout << "Invalid input!";
			cout << endl << "Cost Price: ";
			cin >> temporary.costPrice;
		}
		cout << endl << "Units In Store: ";
		cin >> temporary.unitsInStore;
		while (temporary.unitsInStore < 0)
		{
			cin.ignore();
			cin.clear();
			cout << "Invalid input!";
			cout << endl << "Units In Store: ";
			cin >> temporary.unitsInStore;
		}
		cout << endl << "Units Sold: ";
		cin >> temporary.unitsSold;
		while (temporary.unitsSold < 0)
		{
			cin.ignore();
			cin.clear();
			cout << "Invalid input!";
			cout << endl << "Units Sold: ";
			cin >> temporary.unitsSold;
		}
		cout << endl << "Year of Date First Introduced: ";
		cin >> temporary.yearIntroduced;
		while (temporary.yearIntroduced < 1999 || temporary.yearIntroduced > 2040)
		{
			cin.ignore();
			cin.clear();
			cout << "Invalid input!";
			cout << endl << "Year of Date First Introduced: ";
			cin >> temporary.yearIntroduced;
		}
		cout << endl << "Month of Date First Introduced: ";
		cin >> temporary.monthIntroduced;
		while (temporary.monthIntroduced < 1 || temporary.monthIntroduced > 12)
		{
			cin.ignore();
			cin.clear();
			cout << "Invalid input!";
			cout << endl << "Month of Date First Introduced: ";
			cin >> temporary.monthIntroduced;
		}
		cout << endl << "Day of Date First Introduced: ";
		cin >> temporary.dayIntroduced;
		while (temporary.dayIntroduced < 1 || temporary.dayIntroduced > 31)
		{
			cin.ignore();
			cin.clear();
			cout << "Invalid input!";
			cout << endl << "Day of Date First Introduced: ";
			cin >> temporary.dayIntroduced;
		}
		database.push_back(temporary);
	}
	
	outFile.open("inventory.txt", fstream::app);
	for (int i = 0; i < database.size(); i++)
	{
		outFile << database[i].itemID << endl << database[i].itemName << endl << database[i].itemDescription << endl
				<< database[i].category << endl << database[i].manufacturer << endl << database[i].sellingPrice << endl
				<< database[i].costPrice << endl << database[i].unitsInStore << endl << database[i].unitsSold << endl
				<< database[i].yearIntroduced << endl << database[i].monthIntroduced << endl << database[i].dayIntroduced << endl;
	}
	outFile.close();
	database.clear();
	system("CLS");
}

//updateRecord is a function for the user to update the current inventory record
void StoreItem::updateRecord() 
{
	//The title
	cout << "--------------------------------------------------------------------------------------------------------" << endl
		 << "|                                           RECORD UPDATE                                              |" << endl
		 << "--------------------------------------------------------------------------------------------------------" << endl << endl;
		 
	//Opening the file
	inFile.open("inventory.txt");
	record temporary;
	while(inFile >> temporary.itemID)
	{
		inFile.ignore();
		getline(inFile, temporary.itemName); 
		getline(inFile, temporary.itemDescription); 
		getline(inFile, temporary.category); 
		getline(inFile, temporary.manufacturer); 
		inFile >> temporary.sellingPrice >> temporary.costPrice >> temporary.unitsInStore 
			   >> temporary.unitsSold >> temporary.yearIntroduced >> temporary.monthIntroduced 
			   >> temporary.dayIntroduced;
		database.push_back(temporary);
	}
	
	inFile.close();
	
	//Declaring a variable for the menu
	int recordChoice;
	int updateChoice;
	
	do 
	{
		//The record menu
		for (int i = 0; i < database.size(); i++)
		{
			cout << i << ". " << database[i].itemID << "   " << database[i].itemName << endl;
		}
		
		cout << "If you're done updating, please choose " << database.size() << endl;
		cout << "Choose between 0 to " << (database.size() - 1) << " to pick a record: ";
		cin >> recordChoice;
		
		if (recordChoice < 0 || recordChoice > database.size())
		{
			cout << "Choose between 0 to " << (database.size() - 1) << " to pick a record: ";
			cin >> recordChoice;	
		}
		else if (recordChoice == database.size())
		{
			system("CLS");
			break;
		}
		else
		{
			//The actual menu
			cout << "1. Item ID           7. Cost Price" << endl 
				 << "2. Item Name         8. Units In Store" << endl 
				 << "3. Item Description  9. Units Sold" << endl 
				 << "4. Category          10. Year of Date First Introduced" << endl 
				 << "5. Manufacturer      11. Month of Date First Introduced" << endl 
				 << "6. Selling Price     12. Day of Date First Introduced" << endl
				 << "13. Quit"<< endl;
		 
			cout << endl << "Choose a number: ";
			cin >> updateChoice;
			cin.ignore();
		
			//Validation
			switch(updateChoice) 
			{
				case 1: cout << "Item ID: ";
						cin >> database[recordChoice].itemID;
						cin.ignore();
						cout << endl << endl;
						break;
				case 2: cout << "Item Name: "; 
						getline(cin, database[recordChoice].itemName);
						cout << endl << endl;
						break;
				case 3: cout << "Item Description: "; 
						getline(cin, database[recordChoice].itemDescription);
						cout << endl << endl;
						break;
				case 4: cout << "Category: "; 
						getline(cin, database[recordChoice].category);
						cout << endl << endl;
						break;
				case 5: cout << "Manufacturer: "; 
						getline(cin, database[recordChoice].manufacturer);
						cout << endl << endl;
						break;
				case 6: cout << "Selling Price: ";
						cin >> database[recordChoice].sellingPrice;
						while (database[recordChoice].sellingPrice < 0)
						{
							cin.ignore();
							cin.clear();
							cout << endl << "Invalid input!" << endl;
							cout << "Selling Price: ";
							cin >> database[recordChoice].sellingPrice;
						}
						cin.ignore();
						cout << endl << endl;
						break;
				case 7: cout << "Cost Price: ";
						cin >> database[recordChoice].costPrice;
						while (database[recordChoice].costPrice < 0)
						{
							cin.ignore();
							cin.clear();
							cout << endl << "Invalid input!" << endl;
							cout << "Cost Price: ";
							cin >> database[recordChoice].costPrice;
						}
						cin.ignore();
						cout << endl << endl;
						break;
				case 8: cout << "Units in Store: ";
						cin >> database[recordChoice].unitsInStore;
						while (database[recordChoice].unitsInStore < 0)
						{
							cin.ignore();
							cin.clear();
							cout << endl << "Invalid input!" << endl;
							cout << "Units In Store: ";
							cin >> database[recordChoice].unitsInStore;
						}
						cin.ignore();
						cout << endl << endl;
						break;
				case 9: cout << "Units Sold: ";
						cin >> database[recordChoice].unitsSold;
						while (database[recordChoice].unitsSold < 0)
						{
							cin.ignore();
							cin.clear();
							cout << endl << "Invalid input!" << endl;
							cout << "UnitsSold: ";
							cin >> database[recordChoice].unitsSold;
						}
						cin.ignore();
						cout << endl << endl;
						break;
				case 10: cout << "Year of Date First Introduced: ";
						 cin >> database[recordChoice].yearIntroduced;
						 while (database[recordChoice].yearIntroduced < 1999 || database[recordChoice].yearIntroduced > 2040)
						 {
							cin.ignore();
							cin.clear();
							cout << endl << "Invalid input!" << endl;
							cout << "Year of Date First Introduced: ";
							cin >> database[recordChoice].yearIntroduced;
						 }
						 cin.ignore();
						 cout << endl << endl;
						 break;
				case 11: cout << "Month of Date First Introduced: ";
						 cin >> database[recordChoice].monthIntroduced;
						 while (database[recordChoice].monthIntroduced < 1 || database[recordChoice].monthIntroduced > 12)
						 {
							cin.ignore();
							cin.clear();
							cout << endl << "Invalid input!" << endl;
							cout << "Month of Date First Introduced: ";
							cin >> database[recordChoice].monthIntroduced;
						 }
						 cin.ignore();
						 cout << endl << endl;
						 break;
				case 12: cout << "Day of Date First Introduced: ";
						 cin >> database[recordChoice].dayIntroduced;
						 while (database[recordChoice].dayIntroduced < 1 || database[recordChoice].dayIntroduced > 31)
						 {
							cin.ignore();
							cin.clear();
							cout << endl << "Invalid input!" << endl;
							cout << "Day of Date First Introduced: ";
							cin >> database[recordChoice].dayIntroduced;
						 }
						 cin.ignore();
						 cout << endl << endl;
						 break;
				case 13: break;
				default: cout << "Invalid entry! Please enter a number based on the menu." << endl;	
			}
		}
	} while (recordChoice != database.size());
	
	//Storing all the inputs recieved to a text file
	outFile.open("inventory.txt");
	for (int i = 0; i < database.size(); i++)
	{
		outFile << database[i].itemID << endl << database[i].itemName << endl << database[i].itemDescription << endl
				<< database[i].category << endl << database[i].manufacturer << endl << database[i].sellingPrice << endl
				<< database[i].costPrice << endl << database[i].unitsInStore << endl << database[i].unitsSold << endl
				<< database[i].yearIntroduced << endl << database[i].monthIntroduced << endl << database[i].dayIntroduced << endl;
	}
	outFile.close();
	database.clear();
}

//deleteRecord is a function for the user to delete any data field of an inventory record or the whole record itself
void StoreItem::deleteRecord()
{
	//The title
	cout << "--------------------------------------------------------------------------------------------------------" << endl
		 << "|                                         RECORD DELETION                                              |" << endl
		 << "--------------------------------------------------------------------------------------------------------" << endl << endl;
		 
	//Opening the file
	inFile.open("inventory.txt");
	record temporary;
	while(inFile >> temporary.itemID)
	{
		inFile.ignore();
		getline(inFile, temporary.itemName); 
		getline(inFile, temporary.itemDescription); 
		getline(inFile, temporary.category); 
		getline(inFile, temporary.manufacturer); 
		inFile >> temporary.sellingPrice >> temporary.costPrice >> temporary.unitsInStore 
			   >> temporary.unitsSold >> temporary.yearIntroduced >> temporary.monthIntroduced 
			   >> temporary.dayIntroduced;
		database.push_back(temporary);
	}
	
	inFile.close();
	
	//Declaring a variable for the menu
	int recordChoice;
	int deleteChoice;
		
	do 
	{
		//The record menu
		for (int i = 0; i < database.size(); i++)
		{
			cout << i << ". " << database[i].itemID << "   " << database[i].itemName << endl;
		}
			
		cout << "If you're done updating, please choose " << database.size() << endl;
		cout << "Choose between 0 to " << (database.size() - 1) << " to pick a record: ";
		cin >> recordChoice;
		
		if (recordChoice < 0 || recordChoice > database.size())
		{
			cout << "Choose between 0 to " << (database.size() - 1) << " to pick a record: ";
			cin >> recordChoice;	
		}
		else if (recordChoice == database.size())
		{	
			system("CLS");
			break;
		}
		else
		{
			//The actual menu
			cout << "1. Item ID           7. Cost Price" << endl 
				 << "2. Item Name         8. Units In Store" << endl 
				 << "3. Item Description  9. Units Sold" << endl 
				 << "4. Category          10. Year of Date First Introduced" << endl 
				 << "5. Manufacturer      11. Month of Date First Introduced" << endl 
				 << "6. Selling Price     12. Day of Date First Introduced" << endl
				 << "13. Whole Record     14.Quit"<< endl;
			
			cout << endl << "Choose a number: ";
			cin >> deleteChoice;
			cin.ignore();
			
			//Validation
			switch(deleteChoice) 
			{
				case 1: database[recordChoice].itemID = "-1";
						cout << "Data field deleted." << endl << endl;
						break;
				case 2: database[recordChoice].itemName = "-1";
						cout << "Data field deleted." << endl << endl;
						break;
				case 3: database[recordChoice].itemDescription = "-1";
						cout << "Data field deleted." << endl << endl;
						break;
				case 4: database[recordChoice].category = "-1";
						cout << "Data field deleted." << endl << endl;
						break;
				case 5: database[recordChoice].manufacturer = "-1";
						cout << "Data field deleted." << endl << endl;
						break;
				case 6: database[recordChoice].sellingPrice = -1;
						cout << "Data field deleted." << endl << endl;
						break;
				case 7: database[recordChoice].costPrice = -1;
						cout << "Data field deleted." << endl << endl;
						break;
				case 8: database[recordChoice].unitsInStore = -1;
						cout << "Data field deleted." << endl << endl;
						break;
				case 9: database[recordChoice].unitsSold = -1;
						cout << "Data field deleted." << endl << endl;
						break;
				case 10: database[recordChoice].yearIntroduced = -1;
						 cout << "Data field deleted." << endl << endl;
						 break;
				case 11: database[recordChoice].monthIntroduced = -1;
						 cout << "Data field deleted." << endl << endl;
						 break;
				case 12: database[recordChoice].dayIntroduced = -1;
						 cout << "Data field deleted." << endl << endl;
						 break;
				case 13: if (recordChoice < (database.size() - 1))
						{
							database.erase(database.begin() + recordChoice);
							cout << "Record deleted." << endl << endl;
						}
						else 
						{
							database.pop_back();
							cout << "Record deleted." << endl << endl;
						}
						break;
				case 14: break;
				default: cout << "Invalid entry! Please enter a number based on the menu." << endl;	
			}
		}
	} while (recordChoice != database.size());
	
	//Storing all the inputs recieved to a text file
	outFile.open("inventory.txt");
	for (int i = 0; i < database.size(); i++)
	{
		outFile << database[i].itemID << endl << database[i].itemName << endl << database[i].itemDescription << endl
				<< database[i].category << endl << database[i].manufacturer << endl << database[i].sellingPrice << endl
				<< database[i].costPrice << endl << database[i].unitsInStore << endl << database[i].unitsSold << endl
				<< database[i].yearIntroduced << endl << database[i].monthIntroduced << endl << database[i].dayIntroduced << endl;
	}
	outFile.close();
	
	database.clear();
}

//displayRecord is a function for the user to display all the records based on the data fields
void StoreItem::displayRecord() 
{
	//The title
	cout << "--------------------------------------------------------------------------------------------------------" << endl
		 << "|                                          RECORD DISPLAY                                              |" << endl
		 << "--------------------------------------------------------------------------------------------------------" << endl << endl;
	
	//Opening the file
	inFile.open("inventory.txt");
	record temporary;
	while(inFile >> temporary.itemID)
	{
		inFile.ignore();
		getline(inFile, temporary.itemName); 
		getline(inFile, temporary.itemDescription); 
		getline(inFile, temporary.category); 
		getline(inFile, temporary.manufacturer); 
		inFile >> temporary.sellingPrice >> temporary.costPrice >> temporary.unitsInStore 
			   >> temporary.unitsSold >> temporary.yearIntroduced >> temporary.monthIntroduced 
			   >> temporary.dayIntroduced;
		database.push_back(temporary);
	}
	
	inFile.close();
	
	//Declaring a variable for the menu
	int displayChoice;
	
	do 
	{
		string choice;
		bool swap;
		//The record menu
		for (int i = 0; i < database.size(); i++)
		{
			cout << i << ". " << database[i].itemID << "   " << database[i].itemName << endl;
		}
		//The actual menu
		cout << "1. Item ID           7. Cost Price" << endl 
			 << "2. Item Name         8. Units In Store" << endl 
			 << "3. Item Description  9. Units Sold" << endl 
			 << "4. Category          10. Year of Date First Introduced" << endl 
			 << "5. Manufacturer      11. Month of Date First Introduced" << endl 
			 << "6. Selling Price     12. Day of Date First Introduced" << endl
			 << "13. Whole Record     14. Quit " << endl;
			 
		cout << "Choose a number: ";
		cin >> displayChoice;
		
		//Validation
		switch(displayChoice) 
		{
			case 1: for (int i = 0; i < database.size(); i++)
					{
						if (database[i].itemID != "-1")
							cout << endl << i << ". " << "Item ID: " << database[i].itemID << endl;
					}
					cout << endl;
					break;
			case 2: for (int i = 0; i < database.size(); i++)
					{
						if (database[i].itemName != "-1")
							cout << endl << i << ". " << "Item Name: " << database[i].itemName << endl;
					}
					cout << endl;
					break;
			case 3: for (int i = 0; i < database.size(); i++)
					{
						if (database[i].itemDescription != "-1")
							cout << endl << i << ". " << "Item Description: " << database[i].itemDescription << endl;
					}
					cout << endl;
					break;
			case 4: for (int i = 0; i < database.size(); i++)
					{
						if (database[i].category != "-1")
							cout << endl << i << ". " << "Category: " << database[i].category << endl;
					}
					cout << endl;
					break;
			case 5: for (int i = 0; i < database.size(); i++)
					{
						if (database[i].manufacturer != "-1")
							cout << endl << i << ". " << "Manufacturer: " << database[i].manufacturer << endl;
					}
					cout << endl;
					break;
			case 6: for (int i = 0; i < database.size(); i++)
					{
						if (database[i].sellingPrice != -1)
							cout << endl << i << ". " << "Selling Price: RM " << fixed << setprecision(2) << database[i].sellingPrice << endl;
					}
					cout << endl;
					break;
			case 7: for (int i = 0; i < database.size(); i++)
					{	
						if (database[i].costPrice != -1)
							cout << endl << i << ". " << "Cost Price: RM " << fixed << setprecision(2) << database[i].costPrice << endl;
					}	
					cout << endl;
					break;
			case 8: for (int i = 0; i < database.size(); i++)
					{
						if (database[i].unitsInStore != -1)
							cout << endl << i << ". " << "Units In Store: " << database[i].unitsInStore << endl;
					}
					cout << endl;
					break;
			case 9: for (int i = 0; i < database.size(); i++)
					{
						if (database[i].unitsSold != -1)
							cout << endl << i << ". " << "Units Sold: " << database[i].unitsSold << endl;
					}
					cout << endl;
					break;
			case 10: for (int i = 0; i < database.size(); i++)
					 {
						if (database[i].yearIntroduced != -1)
							cout << endl << i << ". " << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
					 }
					 cout << endl;
					 break;
			case 11: for (int i = 0; i < database.size(); i++)
					 {
						if (database[i].monthIntroduced != -1)
							cout << endl << i << ". " << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
					 }
					 cout << endl;
					 break;
			case 12: for (int i = 0; i < database.size(); i++)
					 {
						if (database[i].dayIntroduced != -1)
							cout << endl << i << ". " << "Day of Date First Introduced: " << database[i].dayIntroduced << endl;
					 }
					 cout << endl;
					 break;
			case 13: for (int i = 0; i < database.size(); i++)
					 {
						cout << endl << endl;
						cout << "---------------------Record " << i << " ----------------------" << endl; 
						if (database[i].itemID != "-1")
							cout << "Item ID: " << database[i].itemID << endl;
						if (database[i].itemName != "-1")
							cout << "Item Name: " << database[i].itemName << endl;
						if (database[i].itemDescription != "-1")
							cout << "Item Description: " << database[i].itemDescription << endl;
						if (database[i].category != "-1")
							cout << "Category: " << database[i].category << endl;
						if (database[i].manufacturer != "-1")
							cout << "Manufacturer: " << database[i].manufacturer << endl;
						if (database[i].sellingPrice != -1)
							cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
						if (database[i].costPrice != -1)
							cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
						if (database[i].unitsInStore != -1)
							cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
						if (database[i].unitsSold != -1)
							cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
						if (database[i].yearIntroduced != -1)
							cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
						if (database[i].monthIntroduced != -1)
							cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
						if (database[i].dayIntroduced != -1)
							cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl; 
					 }
					 break;
			case 14: system("CLS");
					 break;
			default: cout << "Invalid entry! Please enter a number based on the menu." << endl;	
		}
	} while (displayChoice != 14);
	database.clear();
}
//MatchRecord is a function that compares string from the user to all strings in database. Used in searchRecord function
bool StoreItem::MatchRecord(char str1[100], char str3[100])
{
	if (strlen(str1) == strlen(str3))
	{
		for(int k = 0; k < strlen(str1); k++)
		{
			if (str1[k] == str3[k])
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
	}
	else
		return 0;
}

//MatchDoubles is a function that compares doubles or floats from the user to all doubles or floats in database. Used in searchRecord function
bool StoreItem::MatchDoubles(double searchDouble, double j)
{
	if (searchDouble == j)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

//MatchNumbers is a function that compares integers from the user to all integers in database. Used in searchRecord function
bool StoreItem::MatchNumbers(int searchNumber, int k)
{
	if (searchNumber == k)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

//SmallerDoubles is a function that compares doubles or floats from the user to all doubles or floats in database. Used in searchRecord function
bool StoreItem::SmallerDoubles(double searchDouble, double j)
{
	if (j < searchDouble)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

//BiggerDoubles is a function that compares doubles or floats from the user to all doubles or floats in database. Used in searchRecord function
bool StoreItem::BiggerDoubles(double searchDouble, double j)
{
	if (j > searchDouble)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

//SmallerNumbers is a function that compares integers from the user to all integers in database. Used in searchRecord function
bool StoreItem::SmallerNumbers(int searchNumber, int k)
{
	if (k < searchNumber)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

//BiggerNumbers is a function that compares integers from the user to all integers in database. Used in searchRecord function
bool StoreItem::BiggerNumbers(int searchNumber, int k)
{
	if (k > searchNumber)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

//searchRecord is a function for the user to display all the records based on the search fields
void StoreItem::searchRecord()
{
	//The title
	cout << "--------------------------------------------------------------------------------------------------------" << endl
		 << "|                                          SEARCH RECORD                                               |" << endl
		 << "--------------------------------------------------------------------------------------------------------" << endl << endl;
	
	inFile.open("inventory.txt");
	record temporary;
	while(inFile >> temporary.itemID)
	{
		inFile.ignore();
		getline(inFile, temporary.itemName); 
		getline(inFile, temporary.itemDescription); 
		getline(inFile, temporary.category); 
		getline(inFile, temporary.manufacturer); 
		inFile >> temporary.sellingPrice >> temporary.costPrice >> temporary.unitsInStore 
			   >> temporary.unitsSold >> temporary.yearIntroduced >> temporary.monthIntroduced 
			   >> temporary.dayIntroduced;
		database.push_back(temporary);
	}
	
	inFile.close();
	
	int searchChoice;
	int op;
	int typeChoice;
	int result;
	double searchDouble;
	double j;
	int searchNumber;
	int k;
	do
	{
		cout << endl << "1. Search by numbers" << endl << "2. Search by keyword" << endl << "3. Quit" << endl
			 << "Choose a number: ";
		cin >> searchChoice;
		switch (searchChoice)
		{
			case 1: do
					{
						cout << endl << "1. equal to (=)" << endl << "2. less than (<)" << endl << "3. more than (>)" << endl << "4. Quit" << endl
							 << "Enter a number: ";
						cin >> op;
						switch (op)
						{
							case 1: do
									{
										cout << endl << "1. Selling Price" << endl << "2. Cost Price" << endl << "3. Units In Store" << endl << "4. Units Sold" << endl
											 << "5. Year of Date First Introduced" << endl << "6. Month of Date First Introduced" << endl << "7. Day of Date First Introduced"
											 << endl << "8. Quit" << endl << "Enter a number: ";
										cin >> typeChoice;
										switch (typeChoice)
										{
											case 1: cout << endl << "Selling Price: RM ";
													cin >> searchDouble;
													while (searchDouble < 0)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Selling Price: ";
														cin >> searchDouble;
													}
													for(int i = 0; i < database.size(); i++)
													{
														j = database[i].sellingPrice;
														result = MatchDoubles(searchDouble, j);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
											case 2: cout << endl << "Cost Price: RM ";
													cin >> searchDouble;
													while (searchDouble < 0)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Cost Price: ";
														cin >> searchDouble;
													}
													for(int i = 0; i < database.size(); i++)
													{
														j = database[i].costPrice;
														result = MatchDoubles(searchDouble, j);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
											case 3: cout << endl << "Units In Store: ";
													cin >> searchNumber;
													while (searchNumber < 0)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Units In Store: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].unitsInStore;
														result = MatchNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
											case 4: cout << endl << "Units Sold: ";
													cin >> searchNumber;
													while (searchNumber < 0)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Units Sold: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].unitsSold;
														result = MatchNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
											case 5: cout << endl << "Year of Date First Introduced: ";
													cin >> searchNumber;
													while (searchNumber < 1999 || searchNumber > 2040)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Year of Date First Introduced: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].yearIntroduced;
														result = MatchNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl;
														}
													}
													break;
											case 6: cout << endl << "Month of Date First Introduced: ";
													cin >> searchNumber;
													while (searchNumber < 1 || searchNumber > 12)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Month of Date First Introduced: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].monthIntroduced;
														result = MatchNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl;
														}
													}
													break;
											case 7: cout << endl << "Day of Date First Introduced: ";
													cin >> searchNumber;
													while (searchNumber < 1 || searchNumber > 31)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Day of Date First Introduced: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].dayIntroduced;
														result = MatchNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
											case 8: break;
											default : cout << "Invalid input!" << endl;
										}
									} while(typeChoice != 8);
									break;
							case 2: do
									{
										cout << endl << "1. Selling Price" << endl << "2. Cost Price" << endl << "3. Units In Store" << endl << "4. Units Sold" << endl
											 << "5. Year of Date First Introduced" << endl << "6. Month of Date First Introduced" << endl << "7. Day of Date First Introduced"
											 << endl << "8. Quit" << endl << "Enter a number: ";
										cin >> typeChoice;
										switch (typeChoice)
										{
											case 1: cout << endl << "Selling Price: RM ";
													cin >> searchDouble;
													while (searchDouble < 0)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Selling Price: ";
														cin >> searchDouble;
													}
													for(int i = 0; i < database.size(); i++)
													{
														j = database[i].sellingPrice;
														result = SmallerDoubles(searchDouble, j);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
											case 2: cout << endl << "Cost Price: RM ";
													cin >> searchDouble;
													while (searchDouble < 0)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Cost Price: ";
														cin >> searchDouble;
													}
													for(int i = 0; i < database.size(); i++)
													{
														j = database[i].costPrice;
														result = SmallerDoubles(searchDouble, j);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
													
											case 3: cout << endl << "Units In Store: ";
													cin >> searchNumber;
													while (searchNumber < 0)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Units In Store: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].unitsInStore;
														result = SmallerNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
											case 4: cout << endl << "Units Sold: ";
													cin >> searchNumber;
													while (searchNumber < 0)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Units Sold: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].unitsSold;
														result = SmallerNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
											case 5: cout << endl << "Year of Date First Introduced: ";
													cin >> searchNumber;
													while (searchNumber < 1999 || searchNumber > 2040)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Year of Date First Introduced: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].yearIntroduced;
														result = SmallerNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl;
														}
													}
													break;
											case 6: cout << endl << "Month of Date First Introduced: ";
													cin >> searchNumber;
													while (searchNumber < 1 || searchNumber > 12)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Month of Date First Introduced: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].monthIntroduced;
														result = SmallerNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl;
														}
													}
													break;
											case 7: cout << endl << "Day of Date First Introduced: ";
													cin >> searchNumber;
													while (searchNumber < 1 || searchNumber > 31)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Day of Date First Introduced: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].dayIntroduced;
														result = SmallerNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
											case 8: break;
											default : cout << "Invalid input!" << endl;
										}
									} while(typeChoice != 8);
									break;
							case 3: do
									{
										cout << endl << "1. Selling Price" << endl << "2. Cost Price" << endl << "3. Units In Store" << endl << "4. Units Sold" << endl
											 << "5. Year of Date First Introduced" << endl << "6. Month of Date First Introduced" << endl << "7. Day of Date First Introduced"
											 << endl << "8. Quit" << endl << "Enter a number: ";
										cin >> typeChoice;
										switch (typeChoice)
										{
											case 1: cout << endl << "Selling Price: RM ";
													cin >> searchDouble;
													while (searchDouble < 0)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Selling Price: ";
														cin >> searchDouble;
													}
													for(int i = 0; i < database.size(); i++)
													{
														j = database[i].sellingPrice;
														result = BiggerDoubles(searchDouble, j);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
											case 2: cout << endl << "Cost Price: RM ";
													cin >> searchDouble;
													while (searchDouble < 0)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Cost Price: ";
														cin >> searchDouble;
													}
													for(int i = 0; i < database.size(); i++)
													{
														j = database[i].costPrice;
														result = BiggerDoubles(searchDouble, j);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
													
											case 3: cout << endl << "Units In Store: ";
													cin >> searchNumber;
													while (searchNumber < 0)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Units In Store: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].unitsInStore;
														result = BiggerNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
											case 4: cout << endl << "Units Sold: ";
													cin >> searchNumber;
													while (searchNumber < 0)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Units Sold: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].unitsSold;
														result = BiggerNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
											case 5: cout << endl << "Year of Date First Introduced: ";
													cin >> searchNumber;
													while (searchNumber < 1999 || searchNumber > 2040)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Year of Date First Introduced: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].yearIntroduced;
														result = BiggerNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl;
														}
													}
													break;
											case 6: cout << endl << "Month of Date First Introduced: ";
													cin >> searchNumber;
													while (searchNumber < 1 || searchNumber > 12)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Month of Date First Introduced: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].monthIntroduced;
														result = BiggerNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl;
														}
													}
													break;
											case 7: cout << endl << "Day of Date First Introduced: ";
													cin >> searchNumber;
													while (searchNumber < 1 || searchNumber > 31)
													{
														cin.ignore();
														cin.clear();
														cout << "Invalid input!";
														cout << endl << "Year of Date First Introduced: ";
														cin >> searchNumber;
													}
													for(int i = 0; i < database.size(); i++)
													{
														k = database[i].dayIntroduced;
														result = BiggerNumbers(searchNumber, k);
														if (result)
														{
															cout << endl << endl;
															if (database[i].itemID != "-1")
																cout << "Item ID: " << database[i].itemID << endl;
															if (database[i].itemName != "-1")
																cout << "Item Name: " << database[i].itemName << endl;
															if (database[i].itemDescription != "-1")
																cout << "Item Description: " << database[i].itemDescription << endl;
															if (database[i].category != "-1")
																cout << "Category: " << database[i].category << endl;
															if (database[i].manufacturer != "-1")
																cout << "Manufacturer: " << database[i].manufacturer << endl;
															if (database[i].sellingPrice != -1)
																cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
															if (database[i].costPrice != -1)
																cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
															if (database[i].unitsInStore != -1)
																cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
															if (database[i].unitsSold != -1)
																cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
															if (database[i].yearIntroduced != -1)
																cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
															if (database[i].monthIntroduced != -1)
																cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
															if (database[i].dayIntroduced != -1)
																cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
														}
													}
													break;
											case 8: break;
											default : cout << "Invalid input!" << endl;
										}
									} while(typeChoice != 8);
									break;
							case 4: break;
							default: cout << "Invalid input!" << endl;
						}
					}while(op != 4);
					
					break;
			case 2: int typeChoice1;
					char str1[100];
					do
					{
						cout << endl << "1. Item ID" << endl << "2. Item Name" << endl << "3. Item Description" << endl << "4. Category" 
							 << endl << "5. Manufacturer" << endl << "6. Quit" << endl << "Enter a number: ";
						cin >> typeChoice1;
						cin.ignore();
						switch(typeChoice1)
						{
							case 1: cout << endl << "Item ID: ";
									cin.getline(str1, 100);
									for(int i = 0; i < database.size(); i++)
									{
										string str2 = database[i].itemID;
										char str3[100];
										strcpy(str3, str2.data());
			
										int result;
										result = MatchRecord(str1, str3);
										if (result)
										{
											cout << endl << endl;
											if (database[i].itemID != "-1")
												cout << "Item ID: " << database[i].itemID << endl;
											if (database[i].itemName != "-1")
												cout << "Item Name: " << database[i].itemName << endl;
											if (database[i].itemDescription != "-1")
												cout << "Item Description: " << database[i].itemDescription << endl;
											if (database[i].category != "-1")
												cout << "Category: " << database[i].category << endl;
											if (database[i].manufacturer != "-1")
												cout << "Manufacturer: " << database[i].manufacturer << endl;
											if (database[i].sellingPrice != -1)
												cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
											if (database[i].costPrice != -1)
												cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
											if (database[i].unitsInStore != -1)
												cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
											if (database[i].unitsSold != -1)
												cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
											if (database[i].yearIntroduced != -1)
												cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
											if (database[i].monthIntroduced != -1)
												cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
											if (database[i].dayIntroduced != -1)
												cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
										}
									}
									break;
							case 2: cout << endl << "Item Name: ";
									cin.getline(str1, 100);
									for(int i = 0; i < database.size(); i++)
									{
										string str2 = database[i].itemName;
										char str3[100];
										strcpy(str3, str2.data());
			
										int result;
										result = MatchRecord(str1, str3);
										if (result)
										{
											cout << endl << endl;
											if (database[i].itemID != "-1")
												cout << "Item ID: " << database[i].itemID << endl;
											if (database[i].itemName != "-1")
												cout << "Item Name: " << database[i].itemName << endl;
											if (database[i].itemDescription != "-1")
												cout << "Item Description: " << database[i].itemDescription << endl;
											if (database[i].category != "-1")
												cout << "Category: " << database[i].category << endl;
											if (database[i].manufacturer != "-1")
												cout << "Manufacturer: " << database[i].manufacturer << endl;
											if (database[i].sellingPrice != -1)
												cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
											if (database[i].costPrice != -1)
												cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
											if (database[i].unitsInStore != -1)
												cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
											if (database[i].unitsSold != -1)
												cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
											if (database[i].yearIntroduced != -1)
												cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
											if (database[i].monthIntroduced != -1)
												cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
											if (database[i].dayIntroduced != -1)
												cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
										}
									}
									break;
							case 3: cout << endl << "Item Description: ";
									cin.getline(str1, 100);
									for(int i = 0; i < database.size(); i++)
									{
										string str2 = database[i].itemDescription;
										char str3[100];
										strcpy(str3, str2.data());
			
										int result;
										result = MatchRecord(str1, str3);
										if (result)
										{
											cout << endl << endl;
											if (database[i].itemID != "-1")
												cout << "Item ID: " << database[i].itemID << endl;
											if (database[i].itemName != "-1")
												cout << "Item Name: " << database[i].itemName << endl;
											if (database[i].itemDescription != "-1")
												cout << "Item Description: " << database[i].itemDescription << endl;
											if (database[i].category != "-1")
												cout << "Category: " << database[i].category << endl;
											if (database[i].manufacturer != "-1")
												cout << "Manufacturer: " << database[i].manufacturer << endl;
											if (database[i].sellingPrice != -1)
												cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
											if (database[i].costPrice != -1)
												cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
											if (database[i].unitsInStore != -1)
												cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
											if (database[i].unitsSold != -1)
												cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
											if (database[i].yearIntroduced != -1)
												cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
											if (database[i].monthIntroduced != -1)
												cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
											if (database[i].dayIntroduced != -1)
												cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
										}
									}
									break;
							case 4: cout << endl << "Category: ";
									cin.getline(str1, 100);
									for(int i = 0; i < database.size(); i++)
									{
										string str2 = database[i].category;
										char str3[100];
										strcpy(str3, str2.data());
			
										int result;
										result = MatchRecord(str1, str3);
										if (result)
										{
											cout << endl << endl;
											if (database[i].itemID != "-1")
												cout << "Item ID: " << database[i].itemID << endl;
											if (database[i].itemName != "-1")
												cout << "Item Name: " << database[i].itemName << endl;
											if (database[i].itemDescription != "-1")
												cout << "Item Description: " << database[i].itemDescription << endl;
											if (database[i].category != "-1")
												cout << "Category: " << database[i].category << endl;
											if (database[i].manufacturer != "-1")
												cout << "Manufacturer: " << database[i].manufacturer << endl;
											if (database[i].sellingPrice != -1)
												cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
											if (database[i].costPrice != -1)
												cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
											if (database[i].unitsInStore != -1)
												cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
											if (database[i].unitsSold != -1)
												cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
											if (database[i].yearIntroduced != -1)
												cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
											if (database[i].monthIntroduced != -1)
												cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
											if (database[i].dayIntroduced != -1)
												cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
										}
									}
									break;
							case 5: cout << endl << "Manufacturer: ";
									cin.getline(str1, 100);
									for(int i = 0; i < database.size(); i++)
									{
										string str2 = database[i].manufacturer;
										char str3[100];
										strcpy(str3, str2.data());
			
										int result;
										result = MatchRecord(str1, str3);
										if (result)
										{
											cout << endl << endl;
											if (database[i].itemID != "-1")
												cout << "Item ID: " << database[i].itemID << endl;
											if (database[i].itemName != "-1")
												cout << "Item Name: " << database[i].itemName << endl;
											if (database[i].itemDescription != "-1")
												cout << "Item Description: " << database[i].itemDescription << endl;
											if (database[i].category != "-1")
												cout << "Category: " << database[i].category << endl;
											if (database[i].manufacturer != "-1")
												cout << "Manufacturer: " << database[i].manufacturer << endl;
											if (database[i].sellingPrice != -1)
												cout << fixed << setprecision(2) << "Selling Price: RM " << database[i].sellingPrice << endl;
											if (database[i].costPrice != -1)
												cout << fixed << setprecision(2) << "Cost Price: RM " << database[i].costPrice << endl;
											if (database[i].unitsInStore != -1)
												cout << "Units In Store: " << database[i].unitsInStore << " units" << endl;
											if (database[i].unitsSold != -1)
												cout << "Units Sold: " << database[i].unitsSold << " units" << endl;
											if (database[i].yearIntroduced != -1)
												cout << "Year of Date First Introduced: " << database[i].yearIntroduced << endl;
											if (database[i].monthIntroduced != -1)
												cout << "Month of Date First Introduced: " << database[i].monthIntroduced << endl;
											if (database[i].dayIntroduced != -1)
												cout << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
										}
									}
									break;
							case 6: break;
							default: cout << "Invalid input!" << endl;
						}
					}while(typeChoice1 != 6);
					break;
			case 3: system("CLS");
					break;
			default: cout << "Invalid input!" << endl;
		}
	} while(searchChoice != 3);
}