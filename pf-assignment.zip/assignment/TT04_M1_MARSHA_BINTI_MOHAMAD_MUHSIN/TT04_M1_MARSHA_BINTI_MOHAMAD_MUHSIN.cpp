/*******************************************
Program: TT04_M1_MARSHA_BINTI_MOHAMAD_MUHSIN.cpp
Course: Bachelor in Computer Science
Year: 2018/19 Trimester 1
Name: Marsha Binti Mohamad Muhsin
ID: 1171101715
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171101715@student.mmu.edu.my
Phone: 017-8844734
*********************************************/

//Libraries used
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <stdlib.h>
using namespace std;

//Variables used
string itemID, itemName, itemDescription, category, manufacturer, sellingPrice, costPrice, 
	   unitsInStore, unitsSold, yearIntroduced, monthIntroduced, dayIntroduced;

bool file = false; //The text file has not created yet

//Variables for file storage
ifstream inFile;
ofstream outFile;

//insertRecord is a function for the user to insert an inventory record
int insertRecord() 
{
	//The title
	cout << "--------------------------------------------------------------------------------------------------------" << endl
		 << "|                                          RECORD INSERTION                                            |" << endl
		 << "--------------------------------------------------------------------------------------------------------" << endl << endl;
		 
	//All the data fields needed to be input by the user
	cout << "NOTE: Put -1 if you want to delete a data field and press ENTER to continue to next data field" << endl;
	cout << "Item ID: ";
	cin >> itemID;
	cin.ignore();
	cout << endl;
	
	cout << "Item Name: ";
	getline(cin, itemName);
	cout << endl;
	
	cout << "Item Description: ";
	getline(cin, itemDescription);
	cout << endl;
	
	cout << "Category: ";
	getline(cin, category);
	cout << endl;
	
	cout << "Manufacturer: ";
	getline(cin, manufacturer);
	cout << endl;
	
	cout << "Selling Price: ";
	cin >> sellingPrice;
	cout << endl;
	
	cout << "Cost Price: ";
	cin >> costPrice;
	cout << endl;
	
	cout << "Units in Store: ";
	cin >> unitsInStore;
	cout << endl;
	
	cout << "Units Sold: ";
	cin >> unitsSold;
	cout << endl;
	
	cout << "Year of Date First Introduced: ";
	cin >> yearIntroduced;
	cout << endl;
	
	cout << "Month of Date First Introduced: ";
	cin >> monthIntroduced;
	cout << endl;
	
	cout << "Day of Date First Introduced: ";
	cin >> dayIntroduced;
	cout << endl;
	
	//Storing all the inputs recieved to a text file
	outFile.open("inventory.txt");
	outFile << itemID << endl << itemName << endl << itemDescription << endl << category << endl << manufacturer
			<< endl << sellingPrice << endl << costPrice << endl << unitsInStore << endl << unitsSold << endl 
			<< yearIntroduced << endl << monthIntroduced << endl << dayIntroduced << endl;
	outFile.close();
	
	file = true; //The text file has been created by this line
	
	//Clearing the screen
	system("CLS");
	
	return 0;
}

//updateRecord is a function for the user to update the current inventory record
int updateRecord() 
{
	//The title
	cout << "--------------------------------------------------------------------------------------------------------" << endl
		 << "|                                           RECORD UPDATE                                              |" << endl
		 << "--------------------------------------------------------------------------------------------------------" << endl << endl;
		 
	//Opening the file
	inFile.open("inventory.txt");
	inFile >> itemID;
	inFile.ignore();
	getline(inFile, itemName); 
	getline(inFile, itemDescription); 
	getline(inFile, category); 
	getline(inFile, manufacturer); 
	inFile >> sellingPrice >> costPrice >> unitsInStore >> unitsSold >> yearIntroduced >> monthIntroduced >> dayIntroduced;
	inFile.close();
	
	//Declaring a variable for the menu
	int updateChoice;
	
	do 
	{
		//The menu
		cout << "1. Item ID           7. Cost Price" << endl 
			 << "2. Item Name         8. Units In Store" << endl 
			 << "3. Item Description  9. Units Sold" << endl 
			 << "4. Category          10. Year of Date First Introduced" << endl 
			 << "5. Manufacturer      11. Month of Date First Introduced" << endl 
			 << "6. Selling Price     12. Day of Date First Introduced" << endl
			 << "13. Quit"<< endl;
			 
		cout << endl << "NOTE: Put -1 if you want to delete a data field and press ENTER to continue" << endl;
		cout << "Choose a number: ";
		cin >> updateChoice;
		cin.ignore();
		
		//Validation
		switch(updateChoice) 
		{
			case 1: cout << "Item ID: ";
					cin >> itemID;
					cin.ignore();
					cout << endl;
					break;
			case 2: cout << "Item Name: "; 
					getline(cin, itemName);
					cout << endl;
					break;
			case 3: cout << "Item Description: "; 
					getline(cin, itemDescription);
					cout << endl;
					break;
			case 4: cout << "Category: "; 
					getline(cin, category);
					cout << endl;
					break;
			case 5: cout << "Manufacturer: "; 
					getline(cin, manufacturer);
					cout << endl;
					break;
			case 6: cout << "Selling Price: ";
					cin >> sellingPrice;
					cin.ignore();
					cout << endl;
					break;
			case 7: cout << "Cost Price: ";
					cin >> costPrice;
					cin.ignore();
					cout << endl;
					break;
			case 8: cout << "Units in Store: ";
					cin >> unitsInStore;
					cin.ignore();
					cout << endl;
					break;
			case 9: cout << "Units Sold: ";
					cin >> unitsSold;
					cin.ignore();
					cout << endl;
					break;
			case 10: cout << "Year of Date First Introduced: ";
					 cin >> yearIntroduced;
					 cin.ignore();
					 cout << endl;
					 break;
			case 11: cout << "Month of Date First Introduced: ";
					 cin >> monthIntroduced;
					 cin.ignore();
					 cout << endl;
					 break;
			case 12: cout << "Day of Date First Introduced: ";
					 cin >> dayIntroduced;
					 cin.ignore();
					 cout << endl;
					 break;
			case 13: system("CLS");
					 break;
			default: cout << "Invalid entry! Please enter a number based on the menu." << endl;	
		}

	} while (updateChoice != 13);
	
	//Storing all the inputs recieved to a text file
	outFile.open("inventory.txt");
	outFile << itemID << endl << itemName << endl << itemDescription << endl << category << endl << manufacturer
			<< endl << sellingPrice << endl << costPrice << endl << unitsInStore << endl << unitsSold << endl 
			<< yearIntroduced << endl << monthIntroduced << endl << dayIntroduced << endl;
	outFile.close();
	
	return 0;
}

int displayRecord() 
{
	//The title
	cout << "--------------------------------------------------------------------------------------------------------" << endl
		 << "|                                          RECORD DISPLAY                                              |" << endl
		 << "--------------------------------------------------------------------------------------------------------" << endl << endl;
	
	//Opening the file
	inFile.open("inventory.txt");
	inFile >> itemID;
	inFile.ignore();
	getline(inFile, itemName); 
	getline(inFile, itemDescription); 
	getline(inFile, category); 
	getline(inFile, manufacturer); 
	inFile >> sellingPrice >> costPrice >> unitsInStore >> unitsSold >> yearIntroduced >> monthIntroduced >> dayIntroduced;
	inFile.close();
	 
	 //Declaring a variable for the menu
	int displayChoice;
	
	do 
	{
		//The menu
		cout << "1. Item ID           7. Cost Price" << endl 
			 << "2. Item Name         8. Units In Store" << endl 
			 << "3. Item Description  9. Units Sold" << endl 
			 << "4. Category          10. Year of Date First Introduced" << endl 
			 << "5. Manufacturer      11. Month of Date First Introduced" << endl 
			 << "6. Selling Price     12. Day of Date First Introduced" << endl
			 << "13. Whole Record     14. Quit " << endl;
			 
		cout << "Choose a number: ";
		cin >> displayChoice;
		
		//Validation
		switch(displayChoice) 
		{
			case 1: if (itemID != "-1")
						cout << "Item ID: " << itemID << endl;
					else 
						cout << "You have delete the data field!" << endl;
					break;
			case 2: if (itemName != "-1")
						cout << "Item Name: " << itemName << endl;
					else 
						cout << "You have delete the data field!" << endl;
					break;
			case 3: if (itemDescription != "-1")
						cout << "Item Description: " << itemDescription << endl;
					else 
						cout << "You have delete the data field!" << endl;
					break;
			case 4: if (category != "-1")
						cout << "Category: " << category << endl;
					else 
						cout << "You have delete the data field!" << endl;
					break;
			case 5: if (manufacturer != "-1")
						cout << "Manufacturer: " << manufacturer << endl;
					else 
						cout << "You have delete the data field!" << endl;
					break;
			case 6: if (sellingPrice != "-1")
						cout << fixed << setprecision(2) << "Selling Price: RM " << sellingPrice << endl;
					else 
						cout << "You have delete the data field!" << endl;
					break;
			case 7: if (costPrice != "-1")
						cout << fixed << setprecision(2) << "Cost Price: RM " << sellingPrice << endl;
					else 
						cout << "You have delete the data field!" << endl;
					break;
			case 8: if (unitsInStore != "-1")
						cout << "Units In Store: " << unitsInStore << endl;
					else 
						cout << "You have delete the data field!" << endl;
					break;
			case 9: if (unitsSold != "-1")
						cout << "Units Sold: " << unitsSold << endl;
					else 
						cout << "You have delete the data field!" << endl;
					break;
			case 10: if (yearIntroduced != "-1")
						cout << "Year of Date First Introduced: " << yearIntroduced << endl;
					else 
						cout << "You have delete the data field!" << endl;
					break;
			case 11: if (monthIntroduced != "-1")
						cout << "Month of Date First Introduced: " << monthIntroduced << endl;
					else 
						cout << "You have delete the data field!" << endl;
					break;
			case 12: if (dayIntroduced != "-1")
						cout << "Day of Date First Introduced: " << dayIntroduced << endl;
					else 
						cout << "You have delete the data field!" << endl;
					break;
			case 13: cout << endl;
					 if (itemID != "-1")
						cout << "Item ID: " << itemID << endl;
					 if (itemName != "-1")
						cout << "Item Name: " << itemName << endl;
					 if (itemDescription != "-1")
						cout << "Item Description: " << itemDescription << endl;
					 if (category != "-1")
						cout << "Category: " << category << endl;
					 if (manufacturer != "-1")
						cout << "Manufacturer: " << manufacturer << endl;
					 if (sellingPrice != "-1")
						cout << fixed << setprecision(2) << "Selling Price: RM " << sellingPrice << endl;
					 if (costPrice != "-1")
						cout << fixed << setprecision(2) << "Cost Price: RM " << costPrice << endl;
					 if (unitsInStore != "-1")
						cout << "Units In Store: " << unitsInStore << endl;
					 if (unitsSold != "-1")
						cout << "Units Sold: " << unitsSold << endl;
					 if (yearIntroduced != "-1")
						cout << "Year of Date First Introduced: " << yearIntroduced << endl;
					 if (monthIntroduced != "-1")
						cout << "Month of Date First Introduced: " << monthIntroduced << endl;
					 if (dayIntroduced != "-1")
						cout << "Day of Date First Introduced: " << dayIntroduced << endl;
					 break;
			case 14: system("CLS");
					 break;
			default: cout << "Invalid entry! Please enter a number based on the menu." << endl;	
		}
	} while (displayChoice != 14);
	
	return 0;
}

int main()
{
	//Declaring a variable for the menu
	int choice;
	
	do 
	{
		//The title
		cout << "--------------------------------------------------------------------------------------------------------" << endl
			 << "|                                               MAIN MENU                                              |" << endl
			 << "--------------------------------------------------------------------------------------------------------" << endl << endl;
		
		//The menu
		cout << "1. Insert a record" << endl << "2. Update a record" << endl << "3. Display a record" << endl << "4. Quit" << endl;
		cout << "Choose a number: ";
		cin >> choice;
		
		//Validation
		switch (choice)
		{
			case 1: system("CLS");
					insertRecord();
					break;
			case 2: if (file == true)
					{
						system("CLS");
						updateRecord();	
					}
					else
					{
						cout << "You don't have any record for update!" << endl << endl;
					}
					break;
			case 3: if (file == true)
					{
						system("CLS");
						displayRecord();
					}
					else
					{
						cout << "You don't have any record for display!" << endl << endl;
					}
					break;
			case 4: system("CLS");
					break;
			default: cout << "Invalid entry! Please enter a number based on the menu." << endl;			
		}
	} while (choice != 4);
	
	return 0;
}

