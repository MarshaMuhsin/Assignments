#include "test.h"
#include <iostream>
#include <iomanip>
#include <cctype>
#include <fstream>
#include <string>
#include <sstream>
#include <stdlib.h>
#include <vector>
using namespace std;

int main()
{
	//Declaring a variable for the menu
	int choice;
	StoreItem 
	data1;
	
	do 
	{
		//The title
		cout << "--------------------------------------------------------------------------------------------------------" << endl
			 << "|                                               MAIN MENU                                              |" << endl
			 << "--------------------------------------------------------------------------------------------------------" << endl << endl;
		
		//The menu
		cout << "1. Insert a record" << endl << "2. Update a record" << endl << "3. Delete a record" << endl << "4. Display a record" << endl 
			 << "5. Search a record" << endl << "6. Quit" << endl;
		cout << "Choose a number: ";
		cin >> choice;
		
		//Validation
		switch (choice)
		{
			case 1: system("CLS");
					data1.insertRecord();
					break;
			case 2: system("CLS");
					data1.updateRecord();	
					break;
			case 3: system("CLS");
					data1.deleteRecord();
					break;
			case 4: system("CLS");
					data1.displayRecord();
					break;
			case 5: system("CLS"); 
					data1.searchRecord();
					break;
			case 6: system("CLS");
					break;
			default: cout << "Invalid entry! Please enter a number based on the menu." << endl;			
		}
	} while (choice != 6);
	
	return 0;
}
