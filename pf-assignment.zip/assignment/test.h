#ifndef TEST_H
#define TEST_H

#include <iostream>
#include <string>
#include <vector>

using namespace std;

class StoreItem
{
	private:
		struct record
		{
			string itemID, itemName, itemDescription, category, manufacturer;
			double sellingPrice, costPrice;
			int unitsInStore, unitsSold, yearIntroduced, monthIntroduced, dayIntroduced;
		};
		vector<record> database;
	
	public:
		void insertRecord();
		void updateRecord();
		void deleteRecord();
		void displayRecord();
		bool MatchRecord(char *, char *);
		bool MatchDoubles(double , double );
		bool MatchNumbers(int , int );
		bool SmallerDoubles(double , double );
		bool BiggerDoubles(double , double );
		bool SmallerNumbers(int , int );
		bool BiggerNumbers(int , int );
		void searchRecord();
};

#endif