#include <iostream>
#include <iomanip>
#include <cctype>
#include <cstring>
#include <fstream>
#include <string>
#include <sstream>
#include <stdlib.h>
#include <vector>
using namespace std;

struct record
{
	string itemID, itemName, itemDescription, category, manufacturer;
	double sellingPrice, costPrice;
	int unitsInStore, unitsSold, yearIntroduced, monthIntroduced, dayIntroduced;
};

bool MatchRecord(char str1[100], char str3[100])
{
	if (strlen(str1) == strlen(str3))
	{
		for(int k = 0; k < strlen(str1); k++)
		{
			if (str1[k] == str3[k])
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
	}
	else
		return 0;
}

bool MatchDoubles(double searchDouble, double j)
{
	if (searchDouble == j)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
bool MatchNumbers(int searchNumber, int k)
{
	if (searchNumber == k)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int main()
{
	vector<record> database;
	
	ifstream inFile;
	
	inFile.open("inventory.txt");
	record temporary;
	while(inFile >> temporary.itemID)
	{
		inFile.ignore();
		getline(inFile, temporary.itemName); 
		getline(inFile, temporary.itemDescription); 
		getline(inFile, temporary.category); 
		getline(inFile, temporary.manufacturer); 
		inFile >> temporary.sellingPrice >> temporary.costPrice >> temporary.unitsInStore 
			   >> temporary.unitsSold >> temporary.yearIntroduced >> temporary.monthIntroduced 
			   >> temporary.dayIntroduced;
		database.push_back(temporary);
	}
	
	inFile.close();
	
	record search1;
	vector<record> searchList;
	int searchChoice;
	do
	{
		cout << endl << "1. Search by numbers" << endl << "2. Search by keywords" << endl << "3. Quit" << endl
			 << "Choose a number: ";
		cin >> searchChoice;
		switch (searchChoice)
		{
			case 1: int typeChoice;
					int result;
					double searchDouble;
					double j;
					int searchNumber;
					int k;
					do
					{
						cout << endl << "1. Selling Price" << endl << "2. Cost Price" << endl << "3. Units In Store" << endl << "4. Units Sold" << endl
							 << "5. Year of Date First Introduced" << endl << "6. Month of Date First Introduced" << endl << "7. Day of Date First Introduced"
							 << endl << "8. Quit" << "Enter a number: ";
						cin >> typeChoice;
						switch (typeChoice)
						{
							case 1: cout << endl << "Enter a number: ";
									cin >> searchDouble;
									for(int i = 0; i < database.size(); i++)
									{
										j = database[i].sellingPrice;
										result = MatchDoubles(searchDouble, j);
										if (result)
										{
											cout << "Item ID: " << database[i].itemID << endl
												 << "Item Name: " << database[i].itemName << endl
												 << "Item Description: " << database[i].itemDescription << endl
												 << "Category: " << database[i].category << endl
												 << "Manufacturer: " << database[i].manufacturer << endl
												 << "Selling Price: " << database[i].sellingPrice << endl
												 << "Cost Price: " << database[i].costPrice << endl
												 << "Units In Store: " << database[i].unitsInStore << endl
												 << "Units Sold: " << database[i].unitsSold << endl
												 << "Year of Date First Introduced: " << database[i].yearIntroduced << endl
												 << "Month of Date First Introduced: " << database[i].monthIntroduced << endl
												 << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
										}
									}
									break;
							case 2: cout << endl << "Enter a number: ";
									cin >> searchDouble;
									for(int i = 0; i < database.size(); i++)
									{
										j = database[i].costPrice;
										result = MatchDoubles(searchDouble, j);
										if (result)
										{
											cout << "Item ID: " << database[i].itemID << endl
												 << "Item Name: " << database[i].itemName << endl
												 << "Item Description: " << database[i].itemDescription << endl
												 << "Category: " << database[i].category << endl
												 << "Manufacturer: " << database[i].manufacturer << endl
												 << "Selling Price: " << database[i].sellingPrice << endl
												 << "Cost Price: " << database[i].costPrice << endl
												 << "Units In Store: " << database[i].unitsInStore << endl
												 << "Units Sold: " << database[i].unitsSold << endl
												 << "Year of Date First Introduced: " << database[i].yearIntroduced << endl
												 << "Month of Date First Introduced: " << database[i].monthIntroduced << endl
												 << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
										}
									}
									break;
									
							case 3: cout << endl << "Enter a number: ";
									cin >> searchNumber;
									for(int i = 0; i < database.size(); i++)
									{
										k = database[i].unitsInStore;
										result = MatchNumbers(searchNumber, k);
										if (result)
										{
											cout << "Item ID: " << database[i].itemID << endl
												 << "Item Name: " << database[i].itemName << endl
												 << "Item Description: " << database[i].itemDescription << endl
												 << "Category: " << database[i].category << endl
												 << "Manufacturer: " << database[i].manufacturer << endl
												 << "Selling Price: " << database[i].sellingPrice << endl
												 << "Cost Price: " << database[i].costPrice << endl
												 << "Units In Store: " << database[i].unitsInStore << endl
												 << "Units Sold: " << database[i].unitsSold << endl
												 << "Year of Date First Introduced: " << database[i].yearIntroduced << endl
												 << "Month of Date First Introduced: " << database[i].monthIntroduced << endl
												 << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
										}
									}
									break;
							case 4: cout << endl << "Enter a number: ";
									cin >> searchNumber;
									for(int i = 0; i < database.size(); i++)
									{
										k = database[i].unitsSold;
										result = MatchNumbers(searchNumber, k);
										if (result)
										{
											cout << "Item ID: " << database[i].itemID << endl
												 << "Item Name: " << database[i].itemName << endl
												 << "Item Description: " << database[i].itemDescription << endl
												 << "Category: " << database[i].category << endl
												 << "Manufacturer: " << database[i].manufacturer << endl
												 << "Selling Price: " << database[i].sellingPrice << endl
												 << "Cost Price: " << database[i].costPrice << endl
												 << "Units In Store: " << database[i].unitsInStore << endl
												 << "Units Sold: " << database[i].unitsSold << endl
												 << "Year of Date First Introduced: " << database[i].yearIntroduced << endl
												 << "Month of Date First Introduced: " << database[i].monthIntroduced << endl
												 << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
										}
									}
									break;
							case 5: cout << endl << "Enter a number: ";
									cin >> searchNumber;
									for(int i = 0; i < database.size(); i++)
									{
										k = database[i].yearIntroduced;
										result = MatchNumbers(searchNumber, k);
										if (result)
										{
											cout << "Item ID: " << database[i].itemID << endl
												 << "Item Name: " << database[i].itemName << endl
												 << "Item Description: " << database[i].itemDescription << endl
												 << "Category: " << database[i].category << endl
												 << "Manufacturer: " << database[i].manufacturer << endl
												 << "Selling Price: " << database[i].sellingPrice << endl
												 << "Cost Price: " << database[i].costPrice << endl
												 << "Units In Store: " << database[i].unitsInStore << endl
												 << "Units Sold: " << database[i].unitsSold << endl
												 << "Year of Date First Introduced: " << database[i].yearIntroduced << endl
												 << "Month of Date First Introduced: " << database[i].monthIntroduced << endl
												 << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
										}
									}
									break;
							case 6: cout << endl << "Enter a number: ";
									cin >> searchNumber;
									for(int i = 0; i < database.size(); i++)
									{
										k = database[i].monthIntroduced;
										result = MatchNumbers(searchNumber, k);
										if (result)
										{
											cout << "Item ID: " << database[i].itemID << endl
												 << "Item Name: " << database[i].itemName << endl
												 << "Item Description: " << database[i].itemDescription << endl
												 << "Category: " << database[i].category << endl
												 << "Manufacturer: " << database[i].manufacturer << endl
												 << "Selling Price: " << database[i].sellingPrice << endl
												 << "Cost Price: " << database[i].costPrice << endl
												 << "Units In Store: " << database[i].unitsInStore << endl
												 << "Units Sold: " << database[i].unitsSold << endl
												 << "Year of Date First Introduced: " << database[i].yearIntroduced << endl
												 << "Month of Date First Introduced: " << database[i].monthIntroduced << endl
												 << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
										}
									}
									break;
							case 7: cout << endl << "Enter a number: ";
									cin >> searchNumber;
									for(int i = 0; i < database.size(); i++)
									{
										k = database[i].dayIntroduced;
										result = MatchNumbers(searchNumber, k);
										if (result)
										{
											cout << "Item ID: " << database[i].itemID << endl
												 << "Item Name: " << database[i].itemName << endl
												 << "Item Description: " << database[i].itemDescription << endl
												 << "Category: " << database[i].category << endl
												 << "Manufacturer: " << database[i].manufacturer << endl
												 << "Selling Price: " << database[i].sellingPrice << endl
												 << "Cost Price: " << database[i].costPrice << endl
												 << "Units In Store: " << database[i].unitsInStore << endl
												 << "Units Sold: " << database[i].unitsSold << endl
												 << "Year of Date First Introduced: " << database[i].yearIntroduced << endl
												 << "Month of Date First Introduced: " << database[i].monthIntroduced << endl
												 << "Day of Date First Introduced: " << database[i].dayIntroduced << endl << endl;
										}
									}
									break;
							case 8: break;
							default : cout << "Invalid input!" << endl;
						}
					} while(typeChoice != 8);
					break;
			case 2: cout << endl << "Item ID: ";
					cin >> search1.itemID;
					searchList.push_back(search1);
					for (int i = 0; i < searchList.size(); i++)
					{
						string str = searchList[i].itemID;
						char str1[100];
						strcpy(str1, str.data());

						for(int j = 0; j < database.size(); j++)
						{
							string str2 = database[j].itemID;
							char str3[100];
							strcpy(str3, str2.data());
			
							int result;
							result = MatchRecord(str1, str3);
							if (result)
							{
								cout << database[j].itemID << endl;
							}
						}
					}
					searchList.clear();
					break;
			case 3: break;
			default: cout << "Invalid input!" << endl;
		}
	} while(searchChoice != 3);
}
