/*******************************************
Program: TT04_M1_MARSHA_BINTI_MOHAMAD_MUHSIN.h
Course: Bachelor in Computer Science
Year: 2018/19 Trimester 1
Name: Marsha Binti Mohamad Muhsin
ID: 1171101715
Lecture Section: TC02
Tutorial Section: TT04
Email: 1171101715@student.mmu.edu.my
Phone: 017-8844734
*********************************************/
#ifndef STOREITEM_H
#define STOREITEM_H

#include <iostream>
#include <string>
#include <vector>

using namespace std;

class StoreItem
{
	private:
		struct record
		{
			string itemID, itemName, itemDescription, category, manufacturer;
			double sellingPrice, costPrice;
			int unitsInStore, unitsSold, yearIntroduced, monthIntroduced, dayIntroduced;
		};
		vector<record> database;
	
	public:
		void insertRecord();
		void updateRecord();
		void deleteRecord();
		void displayRecord();
		bool MatchRecord(char *, char *);
		bool MatchDoubles(double , double );
		bool MatchNumbers(int , int );
		void searchRecord();
};

#endif