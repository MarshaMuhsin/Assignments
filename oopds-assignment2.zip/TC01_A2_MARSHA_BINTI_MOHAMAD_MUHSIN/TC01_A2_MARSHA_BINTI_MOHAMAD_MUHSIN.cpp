/**********|**********|**********|
Program: TT02_A2_MARSHA_BINTI_MOHAMAD_MUSIN.cpp
Course: Software Engineering
Year: 2018/19 Trimester 2
Name: Marsha Binti Mohamad Muhsin
ID: 1171101715
Lecture Section: TC01
Tutorial Section: TT02
Email: 1171101715@student.mmu.edu.my
Phone: 017-8844734
**********|**********|**********/

#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

//Declaration of classes
class Entry
{
	private:
		int lineNumber;
		string fileName;
	public:
		Entry(){}
		Entry(string& a, int& b)
		{
			fileName = a;
			lineNumber = b;
		}
		void setlineNumber(int l){lineNumber = l;}
		void setfileName(string f){fileName = f;}
		string getfileName(){return fileName;}
		int getlineNumber(){return lineNumber;}
};

class Index
{
	private:
		string indexWord;
		Entry e;
		vector<Entry> ventry;
	public:
		void setindexWord(string & i){indexWord = i;}
		void setEntry(int l, string f)
		{
			e.setlineNumber(l);
			e.setfileName(f);
			ventry.push_back(e);
		}
		string getindexWord(){return indexWord;}
		string getfileName1(){return e.getfileName();}
		int getlineNumber1(){return e.getlineNumber();}
};

//A function that converts an integer to string
string intToString(int counter)
{
	string ch;
	ostringstream outs; 
	outs << counter;   
	ch = outs.str();   
     
	return ch;
}

//Search function that returns a vector of a result
vector<Entry> searchWord(string word, vector<Index> text)
{
	vector<Entry> result;
	string file;
	int lined;
	for(int i = 0; i < text.size(); i++)
	{
		if(word == text[i].getindexWord())
		{
			file = text[i].getfileName1();
			lined = text[i].getlineNumber1();
			Entry ent(file, lined);
			result.push_back(ent);
		}
	}
	return result;
}

int main()
{
	//Declaration of variables and vectors
	string f, input, temp;
	Index ind;
	int counter = 1;
	vector<Index> text;
	vector<string> stopWords;
	ifstream infile;
	
	//Storing stop words into a vector
	infile.open("StopWords.txt");
	while(infile >> input){stopWords.push_back(input);}
	infile.close();
	
	//The reading and storing of all words from all files
	while (counter != 11)
	{
		f = intToString(counter) + ".txt";
		infile.open(f.c_str());
		int l = 1;
		while(getline(infile, temp))
		{
			//Cuts the sentence to word to word
			istringstream ss(temp);
			do
			{
				ss >> input;
				
				//change every character to lower case
				transform(input.begin(), input.end(), input.begin(), ::tolower);
				
				// check if there is punctuation or not 
				for (int k = 0, len = input.size(); k < len; k++) 
				{
					if (ispunct(input[k])) 
					{ 
						input.erase(k--, 1); 
						len = input.size(); 
					}
				}
				
				// check whether the word is a stop word or not
				bool cond = false;
				for(int j = 0; j < stopWords.size(); j++)
				{
					if(input == stopWords[j])
						cond = true;
				}
				
				ind.setindexWord(input);
				ind.setEntry(l, f);
				if(cond == false)
					text.push_back(ind);
			}while(ss);
			for(int j = 1; j < text.size(); j++)
			{
				if(text[j].getindexWord() == text[j-1].getindexWord())
					text.pop_back();
			}
			l++;
		}
		infile.close();
		counter++;
	}
	
	//Search begins here. Uncomment this and comment the checking part
	string word, sentence;
	int li;
	vector <Entry> result;
	do
	{
		cout << "Please enter the search word and q to quit: ";
		cin >> word;
		if(word != "q")
		{
			result = searchWord(word, text);
			if(result.empty())
				cout << "Not Found!" << endl;
			else
			{
				cout << left << setw(20) << "File Name" << setw(20) << "Line Number" << setw(20) << "Sentence" << endl;
				for(int j = 0; j < result.size(); j++)
				{
					f = result[j].getfileName();
					li = result[j].getlineNumber();
					infile.open(f);
					for(int c = 0; c < li; c++)
						getline(infile, sentence);
					infile.close();
					cout << left << setw(20) << f << setw(20) << li << setw(20) << sentence << endl;
				}
			}
		}
	}while(word != "q");
	
	return 0;
}