#include <chrono> //Timer
#include <iostream>
using namespace std;
//Prints the whole array
void printArray(int s[], int size)
{
	cout << "the array is: ";
	for(int i = 0; i < size; i++){cout << s[i]<< " ";}
	cout << endl;
}

// Swapping two values.
void swap(int *a, int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

// Partitioning the array on the basis of values at high as pivot value.
int partition(int s[], int p, int r)
{
	int index = p;
	int pivot = r;

	// Getting index of the pivot.
	for(int i = p; i < r; i++)
	{
		if(s[i] < s[pivot])
		{
			swap(&s[i], &s[index]);
			index++;
		}
	}
	// Swapping value at high and at the index obtained.
	swap(&s[pivot], &s[index]);

	return index;
}

// Random selection of pivot.
int randomPivot(int s[], int p, int r)
{
	int n = rand();
	// Randomizing the pivot value in the given subpart of array.
	int pvt = p + n%(r-p+1);
	// Swapping pivot value from high so that pivot is always the last element.
	swap(&s[r], &s[pvt]);

	return partition(s, p, r);
}
int largestPivot(int s[], int p, int r)
{
	int pvt;
	int largest = s[0];
	for(int i=1; i<r+1; ++i){
		if(largest < s[i]){
			 largest= s[i];
			 pvt = i;
		}
	}
	// Swapping pivot value from high so that pivot is always the last element.
	//cout<<"The largest element is: "<<largest<<" \n";
	swap(&s[r], &s[pvt]);

	return partition(s, p, r);
}

//Implementation of quicksort function
void quicksort(int s[], int p, int r)
{
	if (p < r)
    {
        int pi = partition(s, p, r);
        quicksort(s, p, pi - 1);  //Recursive call for the subarray that is lower than pivot.
        quicksort(s, pi + 1, r);  //Recursive call for the subarray that is higher than pivot.
    }
}

void quicksortRP(int s[], int p, int r)
{
	if (p < r)
    {
        int pi = randomPivot(s, p, r); //Finding pivot randomly (This is fixed pivot i guess)
        quicksortRP(s, p, pi - 1);  //Recursive call for the subarray that is lower than pivot.
        quicksortRP(s, pi + 1, r);  //Recursive call for the subarray that is higher than pivot.
    }
}


void quicksortMP(int s[], int p, int r)
{
	int i = p, j = r;
	int temp;
	int pvt = s[(p+r)/2];
	//cout<<"pivot element is "<<pvt<<"\n";
	//partition
	while (i<=j){
		while (s[i] < pvt){
			i++;
		}
		while (s[j] > pvt){
			j--;
		}
		if (i<=j){
			swap(&s[i], &s[j]);
			i++;
			j--;
		}
	}

	if (p < j){
		quicksortMP(s, p, j);
	}
	if (i < r){
		quicksortMP(s, i, r);
	}
}

void quicksortLP(int s[], int p, int r)
{
	if (p < r)
    {
		int pi = largestPivot(s, p, r);
        quicksortLP(s, p, pi - 1);  //Recursive call for the subarray that is lower than pivot.
        quicksortLP(s, pi + 1, r);  //Recursive call for the subarray that is higher than pivot.
    }
}



int main()
{
	int opt1 = 0;
	int opt2;

	while(opt1!=4){
		cout<<"Test Quick-Sort Algorithm with: "<<"\n";
		cout<<"1.Different array sizes"<<"\n";
		cout<<"2.Different pivot"<<"\n";
		cout<<"3.Different cases"<<"\n";
		cout<<"4.Quit"<<"\n";
		cin>>opt1;
		cout<<"\n";

		switch(opt1){
			case 1:{
				int arrSize;
				cout<<"Enter array size:"<<"\n";
				cin>>arrSize;
				cout<<"\n";
				int n = arrSize;
				srand (time(0));  //Initialize random number generator.
				int* s = new int[n];
				for (int i = 0; i < n; i++)
					s[i] = rand() % RAND_MAX; //Generate randon number range 0 to 32767.

				cout <<"Before ";
				printArray(s, n);
				auto start = chrono::system_clock::now(); //Begin timer
				quicksort(s, 0, n-1); //Call quicksort function
				auto end = chrono::system_clock::now(); //Stop timer
				chrono::duration<double> duration = end - start; //Count how long is the duration
				cout <<"After ";
				printArray(s, n);
				cout << "Duration: " << duration.count() << "s\n\n";
				break;
			}
			case 2:{
				cout<<"Enter which pivot: "<<"\n";
				cout<<"1.Random pivot"<<"\n";
				cout<<"2.Fixed pivot (chooses last element)"<<"\n";
				cin>>opt2;
				cout<<"\n";
				if(opt2==1){
					int arrSize;
					cout<<"Enter array size:"<<"\n";
					cin>>arrSize;
					cout<<"\n";
					int n = arrSize;
					srand (time(0));  //Initialize random number generator.
					int* s = new int[n];
					for (int i = 0; i < n; i++)
						s[i] = rand() % RAND_MAX; //Generate randon number range 0 to 32767.

					cout <<"Before ";
					printArray(s, n);
					auto start = chrono::system_clock::now(); //Begin timer
					quicksortRP(s, 0, n-1); //Call quicksort function
					auto end = chrono::system_clock::now(); //Stop timer
					chrono::duration<double> duration = end - start; //Count how long is the duration
					cout <<"After ";
					printArray(s, n);
					cout << "Duration: " << duration.count() << "s\n\n";
				}
				else{
					int arrSize;
					cout<<"Enter array size:"<<"\n";
					cin>>arrSize;
					cout<<"\n";
					int n = arrSize;
					srand (time(0));  //Initialize random number generator.
					int* s = new int[n];
					for (int i = 0; i < n; i++)
						s[i] = rand() % RAND_MAX; //Generate randon number range 0 to 32767.

					cout <<"Before ";
					printArray(s, n);
					auto start = chrono::system_clock::now(); //Begin timer
					quicksort(s, 0, n-1); //Call quicksort function
					auto end = chrono::system_clock::now(); //Stop timer
					chrono::duration<double> duration = end - start; //Count how long is the duration
					cout <<"After ";
					printArray(s, n);
					cout << "Duration: " << duration.count() << "s\n\n";
				}
				break;
			}
			case 3:{
				cout<<"Enter which case: "<<"\n";
				cout<<"1.Best case (chooses middle element)"<<"\n";
				cout<<"2.Worse case (chooses largest element)"<<"\n";
				cin>>opt2;
				cout<<"\n";
				if(opt2==1){
					int arrSize;
					cout<<"Enter array size:"<<"\n";
					cin>>arrSize;
					cout<<"\n";
					int n = arrSize;
					srand (time(0));  //Initialize random number generator.
					int* s = new int[n];
					for (int i = 0; i < n; i++)
						s[i] = rand() % RAND_MAX; //Generate randon number range 0 to 32767.

					//cout <<"Before ";
					//printArray(s, n);
					auto start = chrono::system_clock::now(); //Begin timer
					quicksortMP(s, 0, n-1); //Call quicksort function
					auto end = chrono::system_clock::now(); //Stop timer
					chrono::duration<double> duration = end - start; //Count how long is the duration
					//cout <<"After ";
					//printArray(s, n);
					cout << "Duration: " << duration.count() << "s\n\n";
				}
				else{
					int arrSize;
					cout<<"Enter array size:"<<"\n";
					cin>>arrSize;
					cout<<"\n";
					int n = arrSize;
					srand (time(0));  //Initialize random number generator.
					int* s = new int[n];
					for (int i = 0; i < n; i++)
						s[i] = rand() % RAND_MAX; //Generate randon number range 0 to 32767.

					//cout <<"Before ";
					//printArray(s, n);
					auto start = chrono::system_clock::now(); //Begin timer
					quicksortLP(s, 0, n-1); //Call quicksort function
					auto end = chrono::system_clock::now(); //Stop timer
					chrono::duration<double> duration = end - start; //Count how long is the duration
					//cout <<"After ";
					//printArray(s, n);
					cout << "Duration: " << duration.count() << "s\n\n";
				}
				break;
			}
		}
	}
	return 0;
}
