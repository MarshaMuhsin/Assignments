#include <chrono> //Timer
#include <iostream>
using namespace std;

//Prints the whole array
void printArray(int s[], int size)
{
	cout << "The array is: ";
	for(int i = 0; i < size; i++){cout << s[i]<< " ";}
	cout << endl;
}

// Swapping two values.
void swap(int *a, int *b)
{ 
	int temp = *a;
	*a = *b;
	*b = temp;
}
 
// Partitioning the array on the basis of values at high as pivot value.
int partition(int s[], int p, int r)
{
	int index = p;
	int pivot = r; //pivot always last element
 
	// Getting index of the pivot.
	for(int i = p; i < r; i++)
	{
		if(s[i] < s[pivot])
		{
			swap(&s[i], &s[index]);
			index++;
		}
	}
	// Swapping value at high and at the index obtained.
	swap(&s[pivot], &s[index]);
 
	return index;
}
 
// Random selection of pivot.
int randomPivot(int s[], int p, int r)
{
	int n = rand();
	
	// Randomizing the pivot value in the given subpart of array.
	int pvt = p + n % (r-p+1);
	
	// Swapping pivot value from high so that pivot is always the last element.
	swap(&s[r], &s[pvt]);
 
	return partition(s, p, r);
}

//Implementation of quicksort function
void quicksort(int s[], int p, int r, string fr)  
{  
	if (p < r)  
    {  
        int pi;
		if(fr == "fixed")
			pi = partition(s, p, r); //Finding pivot (This is fixed pivot i guess)
		else
			pi = randomPivot(s, p, r); //Finding pivot randomly (This is fixed pivot i guess)
        quicksort(s, p, pi - 1, fr);  //Recursive call for the subarray that is lower than pivot.
        quicksort(s, pi + 1, r, fr);  //Recursive call for the subarray that is higher than pivot.
    }  
}

int main()
{
	string fr = "random";
	const int n = 10; //Change the size of the array here.
	srand (time(0));  //Initialize random number generator.
	int* s = new int[n];
	for (int i = 0; i < n; i++)
    s[i] = rand() % 100; //Generate randon number range 0 to 100.
	
	cout << "Array before sorting: ";
	printArray(s, n);
	
	auto start = chrono::system_clock::now(); //Begin timer
	quicksort(s, 0, n-1, fr); //Call quicksort function
	auto end = chrono::system_clock::now(); //Stop timer
	chrono::duration<double> duration = end - start; //Count how long is the duration
	
	cout << "Array after sorting: ";
	printArray(s, n); 
	cout << "Duration: " << duration.count() << "s\n";
	return 0;
}