/**********|**********|**********|**********
Program: main.cpp
Course: Software Engineering
Year: 2018/19 Trimester 2
Name: Marsha Binti Mohamad Muhsin
ID: 1171101715
Lecture Section: TC01
Tutorial Section: TT02
Email: 1171101715@student.mmu.edu.my
Phone: 017-8844734
**********|**********|**********|**********/

#include <cmath>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
//Declaration of global variables
int areaLength, areaWidth, maxAttempts, numberOfSquares, numberOfRectangles, numberOfTriangles, slength, rlength, rwidth, rows;
vector<vector<char>> anArea;
ifstream inFile;
ofstream outFile;

//The Parent Class
class Shapes
{
	public:
		virtual ~Shapes(){};  // Destructor
		
		// available is a function that checks the availability of a certain area
		bool available(int &x, int &y, int &length, int &width, vector<vector<char>> &anArea)
		{
			for(int i = 0; i < width; i++)
			{
				for(int j = 0; j < length; j++)
				{
					if(anArea[y+i][x+j] != '.')
					{
						return false;
						break;
					}
				}
			}
			return true;
				
		}
		
		//outOfBoundary is a function that checks whether the shapes are placed too close to the end of the array
		bool outOfBoundary(int &x, int y, int &length, int &width, vector<vector<char>> &anArea)
		{
			if((x+length) >= (areaLength - 1) || (y+width) >= (areaWidth - 1))
			{
				return false;
			}
			return true;
		}
};

//Subclass rectangle
class Rectangle : public Shapes
{
	private:
		int rLength, rWidth;
		
	public:
		//Constructor of the class
		Rectangle(int rlength, int rwidth): rLength(rlength), rWidth(rwidth){cout << "Rectangle has been created." << endl;}
		
		//Destructor of the class
		~Rectangle(){cout << "Rectangle has been deleted." << endl;}
		
		//printRectangle is a function that saves the rectangle into the array
		void printRectangle(int &x, int &y, int rLength, int rWidth, vector<vector<char>> &anArea)
		{
			for(int row = y; row < (rWidth + y); row++)
			{
				for(int cols = x; cols < (rLength + x); cols++)
				{
					anArea[row][cols] = 'B';
				}
			}
		}
		
		//placingRectangle is a function for random placement of rectangle
		bool placingRectangle()
		{
			int x, y;
			bool result, result2;
			x = rand() % ((areaLength - 1) - rLength);
			y = rand() % ((areaWidth - 1) - rWidth);
			result = outOfBoundary(x, y, rLength, rWidth, anArea);
			result2 = available(x, y, rLength, rWidth, anArea);
			if(result == true && result2 == true)
			{
				printRectangle(x, y, rLength, rWidth, anArea);
				return true;
			}
			else 
			{
				return false;
			}
		}
};

//subclass square
class Square: public Shapes
{
	private:
		int sLength;
		
	public:
		//Constructor of the class
		Square(int slength) : sLength(slength){cout << "Square has been created." << endl;}
		
		//Destructor of the class
		~Square(){cout << "Square has been deleted." << endl;}
		
		//printSquare is a function that saves the square into the array
		void printSquare(int &x, int &y, int sLength, vector<vector<char>> &anArea)
		{
			for(int row = y; row < (sLength + y); row++)
			{
				for(int cols = x; cols < (sLength + x); cols++)
				{
					anArea[row][cols] = 'C';
				}
			}
		}
		
		//placingSquare is a function for random placement of square
		bool placingSquare()
		{
			int x, y;
			bool result, result2;
			x = rand() % ((areaLength - 1) - sLength);
			y = rand() % ((areaWidth - 1) - sLength);
			result = outOfBoundary(x, y, sLength, sLength, anArea);
			result2 = available(x, y, sLength, sLength, anArea);
			if(result == true && result2 == true)
			{
				printSquare(x, y, sLength, anArea);
				return true;
			}
			else 
			{
				return false;
			}
		}
};

class Triangle: public Shapes
{
	private:
		int height, tWidth;
	public:
		//Constructor of the class
		Triangle(int rows): height(rows)
		{
			tWidth = (2 * height) - 1;
			cout << "Triangle has been created." << endl;
		}
		
		//Destructor of the class
		~Triangle(){cout << "Triangle has been deleted." << endl;}
		
		//printTriangle is a function that saves the Triangle into the array
		void printTriangle(int &x, int &y, int height, vector<vector<char>> &anArea) //char anArea[][wid]
		{
			int i = height - 2, j = height + 1;
			anArea[y][height + x] = 'A';
			for(int row = 1; row < height; row++)
			{
				for(int col = i; col < j; col++)
				{
					anArea[row + y][col + (x + 1)] = 'A';
				}
				i = i-1;
				j = j + 1;
			}
		}
		
		//placingTriangle is a function for random placement of Triangle
		bool placingTriangle()
		{
			int x,y;
			bool result, result2;
			x = rand() % ((areaLength - 2) - (2* height));
			y = rand() % ((areaWidth - 1) - height);
			result = outOfBoundary(x, y, height, tWidth, anArea);
			result2 = available(x, y, height, tWidth, anArea);
			if(result == true && result2 == true)
			{
				printTriangle(x, y, height, anArea);
				return true;
				
			}
			else 
			{
				return false;
			}	
		}
};

//Filling the area with dots. Used after declaring the area and to clear the area
void clearArea()
{
	for(int i = 0; i < areaWidth; i++)
	{
		for(int j = 0; j < areaLength; j++)
		{
			anArea[i][j] = '.';
		}
	}
}

void getData(ifstream &inFile, vector<vector<char>> &anArea)
{
	inFile >> areaLength >> areaWidth;
	anArea.resize(areaWidth);
	inFile >> maxAttempts >> numberOfSquares >> slength >> numberOfRectangles >> rlength >> rwidth >> numberOfTriangles >> rows;
	vector<char> v;
	for(int i = 0; i < areaWidth; i++)
	{
		for(int j = 0; j < areaLength; j++)
		{
			v.push_back('.');
		}
		anArea[i] = v;
	}
}

// Convert an integer into a string. Used in naming the file.
string intToString(int a)
{
	string ch;
	ostringstream outs; 
	outs << a;   
	ch = outs.str();   
     
	return ch;
}   

int main()
{
	srand(time(NULL));
	
	
	
	//Retrieving the inputs from the an input file
	inFile.open("FailBatch.txt"); //To see proper success, use SuccessBatch.txt in here.
	if(!inFile) //Checking if the opening of the file is a success
	{
		cout << "Unable to open file" << endl;
		return 1;
	}
	
	getData(inFile, anArea);
	inFile.close();
	/*inFile.open("Batch.txt");
	if(inFile.is_open())
	{
		inFile >> len1 >> wid1 >> maxAttempts >> numberOfSquares;
		if(numberOfSquares >= 1)
		{
			int slength[numberOfSquares];
			for(int i = 0; i < numberOfSquares; i++)
			{
				inFile >> slength[i];
			}
		} 
		inFile >> numberOfRectangles;
		if(numberOfRectangles >= 1)
		{
			int rlength[numberOfRectangles];
			int rwidth[numberOfRectangles];
			for(int i = 0; i < numberOfRectangles; i++)
			{
				inFile >> rlength[i] >> rwidth[i];
			}
		}
		inFile >> numberOfTriangles;
		if(numberOfTriangles >= 1)
		{
			int rows[numberOfTriangles];
			for(int i = 0; i < numberOfTriangles; i++)
			{
				inFile >> rows[i];
				
			}
		}
	}
	else
		cout << "Unable to open file" << endl;
	*/
	
	//clearArea();
	
	//Creating the shapes
	Triangle t(rows);
	Rectangle r(rlength, rwidth);
	Square s(slength);
	
	string fileName;
	int attempts = 0;
	while(attempts < maxAttempts)
	{
		/*for(int i = 0; i < numberOfTriangles; i++)
		{
			Triangle t(rows[i]);
			t.placingTriangle();
		}
		for(int j = 0; j < numberOfRectangles; j++)
		{
			Rectangle r(rlength[j], rwidth[j]);
			r.placingRectangle();
		}
		for(int k = 0; k < numberOfSquares; k++)
		{
			Square s(slength[k]);
			s.placingSquare();
		}*/
		
		bool triangle = t.placingTriangle();
		bool rectangle = r.placingRectangle();
		bool square = s.placingSquare();
		
		int a =  attempts + 1;
		if(triangle == true && rectangle == true && square == true)
		{
			fileName = "Success." + intToString(a) + ".txt";
			outFile.open(fileName.c_str());
			for(int i = 0; i < areaWidth; i++)
			{
				for(int j = 0; j < areaLength; j++)
				{
					outFile << anArea[i][j];
				}
				outFile << endl;
			}
			outFile << endl;
			break;
		}
		else
		{
			fileName = "Fail." + intToString(a) + ".txt";
			outFile.open(fileName.c_str());
			for(int i = 0; i < areaWidth; i++)
			{
				for(int j = 0; j < areaLength; j++)
				{
					outFile << anArea[i][j];
				}
				outFile << endl;
			}
			outFile << endl;
		}
		outFile.close();
		clearArea();
		attempts++;
	}
	return 0;
}