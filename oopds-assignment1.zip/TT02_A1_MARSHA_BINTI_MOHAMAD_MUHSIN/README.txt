This is a program that creates shapes based on an input file that contains the sizes of the shapes and the two-dimensional array then places it in a two-dimensional array.
It is not a complete version as it contains a bug.
1. It can only have a rectangle, a square and a triangle in the program.
I am very sorry about the bug.
In the program, the input file has been set to FailBatch.txt. You can see the bugs of the program easily with this input file.
If you want to see a proper success, change the FailBatch.txt to SuccessBatch.txt.